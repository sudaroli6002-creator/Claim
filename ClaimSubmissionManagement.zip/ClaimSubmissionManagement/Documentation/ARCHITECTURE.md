# System Architecture & Components Overview

## High-Level System Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        END USER (Browser)                       │
└────────────────────────────┬────────────────────────────────────┘
                             │ HTTP/HTTPS
        ┌────────────────────▼────────────────────┐
        │   ASP.NET MVC 5.2 (Port: 80/443)        │
        │   ┌────────────────────────────────┐    │
        │   │  Views (Razor Templates)       │    │
        │   │  - Login.cshtml                │    │
        │   │  - Claim/List.cshtml           │    │
        │   │  - Claim/Add.cshtml            │    │
        │   │  - Claim/Edit.cshtml           │    │
        │   │  - Shared/_Layout.cshtml       │    │
        │   └────────────────────────────────┘    │
        │   ┌────────────────────────────────┐    │
        │   │  MVC Controllers                │    │
        │   │  - ClaimController             │    │
        │   │  - AuthenticationController    │    │
        │   └────────────────────────────────┘    │
        │   ┌────────────────────────────────┐    │
        │   │  Services (Call API)           │    │
        │   │  - ClaimApiService             │    │
        │   │  - AuthenticationService       │    │
        │   └────────────────────────────────┘    │
        └────────────────────┬────────────────────┘
                             │ REST API Calls (JSON)
        ┌────────────────────▼────────────────────┐
        │  ASP.NET Web API (Port: 9090)           │
        │  ┌────────────────────────────────┐     │
        │  │  API Controllers                │     │
        │  │  - ClaimController              │     │
        │  │  - AuthenticationController     │     │
        │  │  POST/GET/PUT/DELETE            │     │
        │  └────────────────────────────────┘     │
        │  ┌────────────────────────────────┐     │
        │  │  Business Logic Services        │     │
        │  │  - ClaimService                 │     │
        │  │  - AuthenticationService        │     │
        │  │  Validation & Rules             │     │
        │  └────────────────────────────────┘     │
        │  ┌────────────────────────────────┐     │
        │  │  DTOs & Models                  │     │
        │  │  - ClaimDTO                     │     │
        │  │  - AuthenticationDTOs           │     │
        │  │  Data Transfer Objects          │     │
        │  └────────────────────────────────┘     │
        │  ┌────────────────────────────────┐     │
        │  │  Data Access Layer              │     │
        │  │  - ClaimDataAccess              │     │
        │  │  - AuthenticationDataAccess     │     │
        │  │  SQL Execution                  │     │
        │  └────────────────────────────────┘     │
        └────────────────────┬────────────────────┘
                             │ ADO.NET Connection
        ┌────────────────────▼────────────────────┐
        │   SQL Server Database                   │
        │   ┌────────────────────────────────┐    │
        │   │  Tables                        │    │
        │   │  - Users                       │    │
        │   │  - Claims                      │    │
        │   └────────────────────────────────┘    │
        │   ┌────────────────────────────────┐    │
        │   │  Stored Procedures             │    │
        │   │  - sp_User_*                   │    │
        │   │  - sp_Claim_*                  │    │
        │   └────────────────────────────────┘    │
        │   ┌────────────────────────────────┐    │
        │   │  Indexes                       │    │
        │   │  - IX_Claims_ClaimNumber       │    │
        │   │  - IX_Claims_ClaimStatus       │    │
        │   └────────────────────────────────┘    │
        └─────────────────────────────────────────┘
```

---

## Component Interaction Flow

### 1. Authentication Flow

```
User Login
    │
    ▼
[Login Page] (Login.cshtml)
    │ User enters credentials
    │
    ▼
[MVC AuthenticationController.Login]
    │ POST to /Authentication/Login
    │
    ▼
[AuthenticationService.LoginAsync]
    │ Calls API endpoint
    │
    ▼
[Web API AuthenticationController.Login]
    │ POST /api/auth/login
    │
    ▼
[API AuthenticationService.Login]
    │ Hash password (SHA256)
    │
    ▼
[AuthenticationDataAccess.ValidateUser]
    │ Execute sp_User_ValidateCredentials
    │
    ▼
[SQL Server]
    │ Validate against Users table
    │ Return UserId
    │
    ▼
[Success] User credentials valid
    │
    ▼
[Generate Token] & [Update LastLogin]
    │
    ▼
[Return LoginResponse]
    │
    ▼
[Store in Session] Store UserId, Token, Username
    │
    ▼
[Redirect] to /Claim/List
```

### 2. Add Claim Flow

```
User Action: Click "Add Claim"
    │
    ▼
[Add Claim Page] (Add.cshtml)
    │ Display form with fields
    │
    ▼
[User Fills Form]
    │ Enter: ClaimNumber, PatientName, ProviderName, DateOfService, Amount, Status
    │
    ▼
[Form Submission] POST /Claim/Add
    │
    ▼
[MVC ClaimController.Add]
    │ ModelState validation
    │ Mandatory field validation
    │
    ▼
[ClaimApiService.CreateClaimAsync]
    │ Call Web API
    │ Add Authorization header
    │
    ▼
[Web API ClaimController.CreateClaim]
    │ POST /api/claims
    │
    ▼
[API ClaimService.CreateClaim]
    │ ValidateClaimRequest()
    │ Check for duplicate ClaimNumber
    │
    ▼
[ClaimDataAccess.CreateClaim]
    │ Execute: sp_Claim_Create
    │ Pass: ClaimNumber, PatientName, ProviderName, DateOfService, ClaimAmount, Status, UserId
    │
    ▼
[SQL Server]
    │ INSERT into Claims table
    │ Set CreatedBy = @UserId
    │ Set CreatedDate = GETUTCDATE()
    │
    ▼
[Return ClaimId] Identity value
    │
    ▼
[Success Response] to MVC
    │
    ▼
[Redirect] to /Claim/List
    │
    ▼
[Display Success Message] "Claim added successfully"
```

### 3. Edit Claim Flow

```
User Action: Click "Edit" button on claim
    │
    ▼
[URL] /Claim/Edit/{claimId}
    │
    ▼
[MVC ClaimController.Edit (GET)]
    │
    ▼
[ClaimApiService.GetClaimByIdAsync]
    │ Fetch claim details from API
    │
    ▼
[Web API ClaimController.GetClaimById]
    │ GET /api/claims/{id}
    │
    ▼
[ClaimDataAccess.GetClaimById]
    │ Execute: sp_Claim_GetById
    │
    ▼
[Load Edit Form] (Edit.cshtml)
    │ Pre-populate with claim data
    │ ClaimNumber: READ-ONLY
    │ Other fields: EDITABLE
    │
    ▼
[User Modifies Fields]
    │ Change: PatientName, ProviderName, DateOfService, Amount, Status
    │
    ▼
[Form Submission] POST /Claim/Edit/{id}
    │
    ▼
[MVC ClaimController.Edit (POST)]
    │ ModelState validation
    │
    ▼
[ClaimApiService.UpdateClaimAsync]
    │ Call Web API
    │
    ▼
[Web API ClaimController.UpdateClaim]
    │ PUT /api/claims/{id}
    │
    ▼
[API ClaimService.UpdateClaim]
    │ Validate request
    │ Check claim exists
    │
    ▼
[ClaimDataAccess.UpdateClaim]
    │ Execute: sp_Claim_Update
    │ Pass: ClaimId, PatientName, ProviderName, DateOfService, Amount, Status, UserId
    │
    ▼
[SQL Server]
    │ UPDATE Claims table
    │ Set LastModifiedBy = @UserId
    │ Set LastModifiedDate = GETUTCDATE()
    │
    ▼
[Success Response]
    │
    ▼
[Redirect] to /Claim/List
    │
    ▼
[Display Success Message] "Claim updated successfully"
```

### 4. List Claims Flow

```
User Action: Click "Claims" in navbar OR access /Claim/List
    │
    ▼
[MVC ClaimController.List]
    │ Query parameters: pageNumber, pageSize
    │
    ▼
[ClaimApiService.GetAllClaimsAsync]
    │ Call Web API with pagination params
    │
    ▼
[Web API ClaimController.GetAllClaims]
    │ GET /api/claims?pageNumber=1&pageSize=10
    │
    ▼
[API ClaimService.GetAllClaims]
    │ Validate page parameters
    │
    ▼
[ClaimDataAccess.GetAllClaims]
    │ Execute: sp_Claim_GetAll (pagination query)
    │ Execute: sp_Claim_GetCount
    │
    ▼
[SQL Server]
    │ Fetch claims with OFFSET/FETCH
    │ Get total claim count
    │
    ▼
[Return PaginationResponse]
    │ Items: List of ClaimDTO
    │ PageNumber, PageSize, TotalItems
    │
    ▼
[Load List.cshtml]
    │ Display claims in table
    │ Show status badges with colors
    │ Show Edit buttons
    │ Show Add Claim button
    │
    ▼
[Display to User]
    │ Table with sortable columns
    │ Pagination controls (if needed)
    │ Action buttons per row
```

---

## Data Flow Diagrams

### Input Validation Flow

```
User Input (Form Data)
    │
    ▼
[Model Validation] ASP.NET ModelState
    │ Check required fields
    │ Check data types
    │
    ├─ Invalid? → Display errors → Return form
    │
    ▼ Valid
[Service Validation] ClaimService.ValidateClaimRequest()
    │ Check mandatory fields: {FieldName} is mandatory.
    │ Check business rules
    │ Check duplicates
    │
    ├─ Invalid? → Return error list → BadRequest
    │
    ▼ Valid
[Database Operation] Stored Procedure execute
    │
    ▼
[Success/Failure Response]
```

### Database Operation Flow

```
[Data Access Class]
    │ ClaimDataAccess.CreateClaim()
    │
    ▼
[Create SqlConnection]
    │ Open connection
    │
    ▼
[Create SqlCommand]
    │ Set CommandType = StoredProcedure
    │ Set CommandText = "sp_Claim_Create"
    │
    ▼
[Add Parameters]
    │ @ClaimNumber, @PatientName, @ProviderName, @DateOfService, @ClaimAmount, @ClaimStatus, @CreatedBy
    │ @ClaimId (OUTPUT)
    │
    ▼
[Execute NonQuery]
    │ Stored procedure executes on SQL Server
    │
    ▼
[Get Output Parameters]
    │ Retrieve @ClaimId value
    │
    ▼
[Close Connection]
    │ Return claimId to caller
```

---

## Security Implementation

```
┌─────────────────────────────────────────┐
│        Authentication & Authorization    │
├─────────────────────────────────────────┤
│                                         │
│ 1. Password Storage                     │
│    User Input → SHA256 Hash → Storage   │
│                                         │
│ 2. Identity Verification                │
│    Login Request → Hash Compare         │
│    → Token Generation                   │
│                                         │
│ 3. Session Management                   │
│    Session["UserToken"]                 │
│    FormsAuthenticationTicket            │
│                                         │
│ 4. API Authorization                    │
│    Bearer Token in Header               │
│    ValidateUser() call                  │
│                                         │
│ 5. Database Security                    │
│    SQL Parameters (no SQL injection)    │
│    Stored procedures only               │
│    No inline SQL queries                │
│                                         │
└─────────────────────────────────────────┘
```

---

## Error Handling & Response Format

```
Request
    │
    ▼
[Controller Method]
    │
    ├─ If Validation Error
    │   └─ ApiResponse<object>
    │       {
    │         "success": false,
    │         "message": "Validation failed",
    │         "errors": ["Field Name is mandatory."]
    │       }
    │
    ├─ If Business Logic Error
    │   └─ BadRequest("Error message")
    │
    ├─ If Not Found
    │   └─ HttpNotFound();
    │
    ├─ If Unauthorized
    │   └─ Unauthorized();
    │
    ├─ If Database Error
    │   └─ InternalServerError()
    │
    └─ If Success
        └─ ApiResponse<T>
            {
              "success": true,
              "message": "Operation successful",
              "data": { ... }
            }
```

---

## Service Layer Responsibilities

### ClaimService
- **Validate** all claim inputs
- **Check** for duplicate claim numbers
- **Verify** claim exists before updates
- **Call** data access layer
- **Transform** data for API responses
- **Handle** business exceptions

### AuthenticationService
- **Validate** login credentials
- **Hash** passwords using SHA256
- **Check** password strength
- **Create** authentication tokens
- **Manage** user registration
- **Handle** unauthorized access

### ClaimApiService (MVC)
- **Convert** MVC models to API DTOs
- **Call** Web API endpoints
- **Handle** HTTP requests/responses
- **Parse** JSON responses
- **Map** API responses to ViewModels
- **Handle** API communication errors

### AuthenticationService (MVC)
- **Call** API login endpoint
- **Handle** login responses
- **Extract** user information
- **Manage** authentication errors

---

## Pagination Implementation

```
Frontend Request: /Claim/List?pageNumber=1&pageSize=10
    │
    ▼
[Controller Parameters] pageNumber, pageSize
    │
    ▼
[Service Validation]
    If pageNumber < 1 → Set pageNumber = 1
    If pageSize < 1 or > 100 → Set pageSize = 10
    │
    ▼
[SQL Calculation]
    @SkipRows = (pageNumber - 1) * pageSize
    
    SELECT ... 
    ORDER BY CreatedDate DESC
    OFFSET @SkipRows ROWS
    FETCH NEXT @pageSize ROWS ONLY
    │
    ▼
[Count Query]
    SELECT COUNT(*) AS TotalItems FROM Claims
    │
    ▼
[PaginationResponse<T>]
    {
      "items": [ ... ],
      "pageNumber": 1,
      "pageSize": 10,
      "totalItems": 47
    }
```

---

## Status Badge Mapping

```
Claim Status (Database) → Badge Color (UI)

"Submitted"      → info    (Blue)      #17a2b8
"Under Review"   → warning (Orange)    #ffc107
"Approved"       → success (Green)     #28a745
"Rejected"       → danger  (Red)       #dc3545
Other/Default    → secondary (Gray)    #6c757d
```

---

## Key Design Patterns Used

### 1. **Three-Tier Architecture**
- Separation of concerns
- Scalability
- Maintainability

### 2. **Service Layer Pattern**
- Business logic encapsulation
- Reusability
- Testability

### 3. **Data Access Layer Pattern**
- Database abstraction
- Stored procedure management
- Query encapsulation

### 4. **DTO (Data Transfer Object) Pattern**
- API contract definition
- Data mapping
- Security (expose only needed fields)

### 5. **Repository Pattern** (via DataAccess)
- Data access abstraction
- Consistency in data operations
- Easy to test

### 6. **MVC Pattern**
- Clear separation: Model, View, Controller
- Reusable components
- Testable code

### 7. **Middleware/Filter Pattern**
- Authentication/Authorization
- Request/Response handling
- Cross-cutting concerns

---

## Performance Considerations

```
Database Performance
    ├─ Index on ClaimNumber (for GetByClaimNumber)
    │
    ├─ Index on ClaimStatus (for filtering)
    │
    ├─ Pagination with OFFSET/FETCH
    │
    └─ Stored procedures (compiled execution)

API Performance
    ├─ Async/await patterns
    │
    ├─ Connection pooling
    │
    ├─ Minimal data transfer (DTOs)
    │
    └─ Caching opportunities (future)

Frontend Performance
    ├─ Bootstrap CDN (lighter)
    │
    ├─ Async HTTP calls
    │
    ├─ Minimal page refreshes
    │
    └─ Client-side validation
```

---

## Future Scalability Points

1. **Database**: Implement replication, sharding
2. **API**: Add caching layer (Redis)
3. **Frontend**: Implement SPA (Angular/React)
4. **Architecture**: Move to microservices
5. **Authentication**: Implement OAuth 2.0/OpenID
6. **Monitoring**: Add logging, APM tools
7. **Testing**: Add unit tests, integration tests
8. **API**: Implement versioning (v1, v2)

---

Document Version: 1.0  
Created: March 9, 2026  
For: Claim Submission Management App v1.0
