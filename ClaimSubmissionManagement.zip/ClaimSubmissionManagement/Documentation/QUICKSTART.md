# Quick Start Guide - Claim Submission Management App

## 5-Minute Setup Guide

### Step 1: Database Setup (2 minutes)
1. Open **SQL Server Management Studio**
2. Execute these scripts in order:
   ```
   Database/001_CreateDatabase.sql
   Database/002_AuthenticationStoredProcedures.sql
   Database/003_ClaimStoredProcedures.sql
   Database/004_SampleData.sql
   ```

### Step 2: Update Configuration (1 minute)

**API Configuration** - Edit `ClaimSubmissionManagement.API/Web.config`:
```xml
<connection name="ClaimSubmissionDB" 
    connectionString="Server=.;Database=ClaimSubmissionDB;User ID=sa;Password=YourPassword123!;" />
```

**MVC Configuration** - Edit `ClaimSubmissionManagement.MVC/Web.config`:
```xml
<add key="ApiBaseUrl" value="http://localhost:9090" />
```

### Step 3: Open to IIS Express (2 minutes)

1. Open `ClaimSubmissionManagement.sln` in Visual Studio
2. Right-click **ClaimSubmissionManagement.API** → Properties → Web
   - Set URL: `http://localhost:9090`
3. Right-click **ClaimSubmissionManagement.MVC** → Properties → Web
   - Set URL: `http://localhost`
4. Press **F5** to start debugging

---

## Default Login Credentials
```
Username: admin
Password: Admin@123
```

---

## Main Features at a Glance

### From Home Page
| Feature | Action | Location |
|---------|--------|----------|
| View All Claims | Click "Claims" in navbar | /Claim/List |
| Create New Claim | Click "Add Claim" button | /Claim/Add |
| Edit Existing Claim | Click "Edit" on claim row | /Claim/Edit/{id} |
| Logout | Click username → Logout | /Authentication/Logout |

---

## API Endpoints Quick Reference

### Authentication
```
POST /api/auth/login
```

### Claims
```
GET    /api/claims              (Get all)
GET    /api/claims/{id}         (Get one)
POST   /api/claims              (Create)
PUT    /api/claims/{id}         (Update)
DELETE /api/claims/{id}         (Delete)
```

---

## File Structure at a Glance

```
ClaimSubmissionManagement/
├── Database/                   ← SQL Scripts
├── Documentation/              ← This file
├── ClaimSubmissionManagement.API/
│   ├── Controllers/            ← API Endpoints
│   ├── Services/               ← Business Logic
│   ├── DataAccess/             ← Database Access
│   └── DTOs/                   ← Data Models
├── ClaimSubmissionManagement.MVC/
│   ├── Controllers/            ← MVC Actions
│   ├── Views/                  ← HTML Pages
│   ├── Models/                 ← ViewModels
│   └── Services/               ← API Calls
└── ClaimSubmissionManagement.sln
```

---

## Common Tasks

### Add a New Claim
1. Login with admin credentials
2. Click "Add Claim" button
3. Fill all mandatory fields:
   - Claim Number (unique)
   - Patient Name
   - Provider Name
   - Date of Service
   - Claim Amount
   - Claim Status (dropdown)
4. Click "Save Claim"

### Find a Specific Claim
1. Navigate to Claims list
2. Look through table (supports pagination)
3. Click "Edit" button to view/modify

### Change Claim Status
1. Click "Edit" on a claim
2. Change the "Claim Status" dropdown
3. Click "Update Claim"

---

## Database Tables Reference

### Users Table
- UserId (PK)
- Username
- PasswordHash
- Email
- FullName
- IsActive

### Claims Table
- ClaimId (PK)
- ClaimNumber (UNIQUE)
- PatientName
- ProviderName
- DateOfService
- ClaimAmount
- ClaimStatus
- CreatedBy (FK → Users)
- CreatedDate
- LastModifiedBy (FK → Users)
- LastModifiedDate

---

## Status Codes & Messages

### Success Responses
```json
{
    "success": true,
    "message": "Operation completed successfully",
    "data": { ... }
}
```

### Error Responses
```json
{
    "success": false,
    "message": "Error description",
    "errors": ["Field Name is mandatory."]
}
```

### Validation Error Format
All mandatory field errors follow the pattern:
```
"{FieldName} is mandatory."
```

---

## Helpful Tips

✓ **For Development**: 
- Use Visual Studio's debugger (F9 for breakpoints)
- Check Output window for API responses
- Monitor SQL Server logs for query issues

✓ **For Testing**:
- Use Postman for API testing
- Create test users via `/api/auth/register`
- Use sample data from `004_SampleData.sql`

✓ **For Deployment**:
- Update API base URL in MVC Web.config
- Ensure database firewall rules allow connections
- Test cross-server API calls before production

---

## Architecture Overview

```
┌─ User Browser ─────────────┐
│   ASP.NET MVC UI          │
│   (Claim/Authentication)    │
└────────────┬───────────────┘
             │ HTTP Calls
┌────────────▼───────────────┐
│   ASP.NET Web API         │
│   (Business Logic)         │
│   Stored Procedure Calls   │
└────────────┬───────────────┘
             │ SQL Queries
┌────────────▼───────────────┐
│   SQL Server Database      │
│   Tables & Stored Procs    │
└────────────────────────────┘
```

---

## Mandatory Fields Validation

### Add/Edit Claim Form
- **Claim Number**: "Claim Number is mandatory."
- **Patient Name**: "Patient Name is mandatory."
- **Provider Name**: "Provider Name is mandatory."
- **Date of Service**: "Date of Service is mandatory."
- **Claim Amount**: "Claim Amount is mandatory."
- **Claim Status**: "Claim Status is mandatory."

---

## Key Components Explained

**Controllers**
- Handle HTTP requests/responses
- API: `/Controllers/` - REST endpoints
- MVC: `/Controllers/` - Page actions

**Services**
- Contains business logic
- Validation rules implementation
- Data transformation

**Data Access**
- Executes stored procedures
- Manages SQL connections
- Maps database rows to objects

**Views**
- HTML templates (Razor)
- Bootstrap-based responsive design
- Form validation display

---

## Support Resources

📖 **Full Documentation**: `Documentation/README.md`  
🗂️ **Database Scripts**: `Database/` folder  
💻 **API Reference**: See API Endpoints in full docs  
🎨 **UI Components**: Built with Bootstrap 5  

---

Version 1.0 | Created March 9, 2026
