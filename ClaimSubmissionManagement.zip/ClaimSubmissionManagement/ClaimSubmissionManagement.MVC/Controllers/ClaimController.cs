using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Mvc;
using ClaimSubmissionManagement.MVC.Models;
using ClaimSubmissionManagement.MVC.Services;

namespace ClaimSubmissionManagement.MVC.Controllers
{
    /// <summary>
    /// MVC Controller for Claim Management UI
    /// Handles interactions with Web API for claim operations
    /// </summary>
    [Authorize]
    public class ClaimController : Controller
    {
        private readonly IClaimApiService _claimApiService;

        public ClaimController()
        {
            // Create instance of ClaimApiService - URL should be configured in web.config
            string apiBaseUrl = System.Configuration.ConfigurationManager.AppSettings["ApiBaseUrl"] ?? "http://localhost:9090";
            _claimApiService = new ClaimApiService(apiBaseUrl);
        }

        /// <summary>
        /// GET: Claim/List
        /// Display list of all claims in tabular format
        /// </summary>
        public async Task<ActionResult> List(int pageNumber = 1, int pageSize = 10)
        {
            try
            {
                string token = GetUserToken();
                List<ClaimListViewModel> claims = await _claimApiService.GetAllClaimsAsync(token, pageNumber, pageSize);
                return View(claims);
            }
            catch (Exception ex)
            {
                ViewBag.Message = $"Error loading claims: {ex.Message}";
                return View(new List<ClaimListViewModel>());
            }
        }

        /// <summary>
        /// GET: Claim/Add
        /// Display Add Claim page
        /// </summary>
        public ActionResult Add()
        {
            return View(new AddClaimViewModel());
        }

        /// <summary>
        /// POST: Claim/Add
        /// Save new claim to database
        /// Validates all mandatory fields
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Add(AddClaimViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var errors = new List<string>();
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var error in modelState.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                ViewBag.ValidationErrors = errors;
                return View(model);
            }

            try
            {
                string token = GetUserToken();
                int claimId = await _claimApiService.CreateClaimAsync(token, model);

                if (claimId > 0)
                {
                    ViewBag.Message = "Claim added successfully";
                    return RedirectToAction("List");
                }
                else
                {
                    ViewBag.Error = "Failed to create claim";
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error creating claim: {ex.Message}";
                return View(model);
            }
        }

        /// <summary>
        /// GET: Claim/Edit/{id}
        /// Display Edit Claim page with claim details
        /// </summary>
        public async Task<ActionResult> Edit(int id)
        {
            try
            {
                string token = GetUserToken();
                ClaimListViewModel claim = await _claimApiService.GetClaimByIdAsync(token, id);

                if (claim == null)
                {
                    return HttpNotFound();
                }

                var editModel = new EditClaimViewModel
                {
                    ClaimId = claim.ClaimId,
                    ClaimNumber = claim.ClaimNumber,
                    PatientName = claim.PatientName,
                    ProviderName = claim.ProviderName,
                    DateOfService = claim.DateOfService,
                    ClaimAmount = claim.ClaimAmount,
                    ClaimStatus = claim.ClaimStatus
                };

                return View(editModel);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error loading claim: {ex.Message}";
                return RedirectToAction("List");
            }
        }

        /// <summary>
        /// POST: Claim/Edit/{id}
        /// Update claim details
        /// Validates all mandatory fields
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Edit(int id, EditClaimViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var errors = new List<string>();
                foreach (var modelState in ModelState.Values)
                {
                    foreach (var error in modelState.Errors)
                    {
                        errors.Add(error.ErrorMessage);
                    }
                }
                ViewBag.ValidationErrors = errors;
                return View(model);
            }

            try
            {
                model.ClaimId = id;
                string token = GetUserToken();
                await _claimApiService.UpdateClaimAsync(token, model);

                ViewBag.Message = "Claim updated successfully";
                return RedirectToAction("List");
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error updating claim: {ex.Message}";
                return View(model);
            }
        }

        /// <summary>
        /// POST: Claim/Delete/{id}
        /// Delete a claim
        /// </summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Delete(int id)
        {
            try
            {
                string token = GetUserToken();
                await _claimApiService.DeleteClaimAsync(token, id);

                return RedirectToAction("List");
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Error deleting claim: {ex.Message}";
                return RedirectToAction("List");
            }
        }

        /// <summary>
        /// Helper method to get user token from session
        /// </summary>
        private string GetUserToken()
        {
            if (Session["UserToken"] != null)
            {
                return Session["UserToken"].ToString();
            }
            return string.Empty;
        }
    }
}
