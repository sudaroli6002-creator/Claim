using System;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Security;
using ClaimSubmissionManagement.MVC.Models;
using ClaimSubmissionManagement.MVC.Services;

namespace ClaimSubmissionManagement.MVC.Controllers
{
    /// <summary>
    /// MVC Controller for User Authentication
    /// Handles login and logout functionality
    /// </summary>
    public class AuthenticationController : Controller
    {
        private readonly IAuthenticationService _authService;

        public AuthenticationController()
        {
            string apiBaseUrl = System.Configuration.ConfigurationManager.AppSettings["ApiBaseUrl"] ?? "http://localhost:9090";
            _authService = new AuthenticationService(apiBaseUrl);
        }

        /// <summary>
        /// GET: Authentication/Login
        /// Display login page
        /// </summary>
        [AllowAnonymous]
        public ActionResult Login()
        {
            return View(new LoginViewModel());
        }

        /// <summary>
        /// POST: Authentication/Login
        /// Authenticate user credentials and establish session
        /// </summary>
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            try
            {
                UserViewModel user = await _authService.LoginAsync(model);

                if (user != null)
                {
                    // Store user information in session
                    Session["UserId"] = user.UserId;
                    Session["Username"] = user.Username;
                    Session["FullName"] = user.FullName;
                    Session["UserToken"] = user.Token;
                    Session["IsAuthenticated"] = true;

                    // Optional: Create FormsAuthenticationTicket for additional security
                    FormsAuthenticationTicket ticket = new FormsAuthenticationTicket(
                        version: 1,
                        name: user.Username,
                        issueDate: DateTime.Now,
                        expiration: DateTime.Now.AddHours(12),
                        isPersistent: model.RememberMe,
                        userData: user.UserId.ToString());

                    string encryptedTicket = FormsAuthentication.Encrypt(ticket);
                    HttpCookie authCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
                    Response.Cookies.Add(authCookie);

                    return RedirectToAction("List", "Claim");
                }
                else
                {
                    ViewBag.Error = "Invalid username or password";
                    return View(model);
                }
            }
            catch (UnauthorizedAccessException)
            {
                ViewBag.Error = "Invalid username or password";
                return View(model);
            }
            catch (Exception ex)
            {
                ViewBag.Error = $"Login error: {ex.Message}";
                return View(model);
            }
        }

        /// <summary>
        /// GET: Authentication/Logout
        /// Clear user session and log out
        /// </summary>
        [Authorize]
        public ActionResult Logout()
        {
            Session.Clear();
            Session.Abandon();
            FormsAuthentication.SignOut();
            return RedirectToAction("Login");
        }
    }
}
