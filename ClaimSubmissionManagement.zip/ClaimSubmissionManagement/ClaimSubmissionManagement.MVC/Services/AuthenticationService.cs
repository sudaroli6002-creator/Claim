using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ClaimSubmissionManagement.MVC.Models;

namespace ClaimSubmissionManagement.MVC.Services
{
    /// <summary>
    /// Service to communicate with Web API for authentication
    /// </summary>
    public interface IAuthenticationService
    {
        Task<UserViewModel> LoginAsync(LoginViewModel login);
    }

    public class AuthenticationService : IAuthenticationService
    {
        private readonly string _apiBaseUrl;
        private readonly HttpClient _httpClient;

        public AuthenticationService(string apiBaseUrl)
        {
            _apiBaseUrl = apiBaseUrl;
            _httpClient = new HttpClient();
        }

        /// <summary>
        /// Login user with username and password via API
        /// </summary>
        public async Task<UserViewModel> LoginAsync(LoginViewModel login)
        {
            try
            {
                if (login == null || string.IsNullOrWhiteSpace(login.Username) || string.IsNullOrWhiteSpace(login.Password))
                {
                    throw new ArgumentException("Username and password are required");
                }

                string url = $"{_apiBaseUrl}/api/auth/login";

                var content = new StringContent(
                    JsonConvert.SerializeObject(new { 
                        username = login.Username, 
                        password = login.Password 
                    }),
                    System.Text.Encoding.UTF8,
                    "application/json");

                using (var response = await _httpClient.PostAsync(url, content))
                {
                    if (response.IsSuccessStatusCode)
                    {
                        var responseContent = await response.Content.ReadAsStringAsync();
                        dynamic result = JsonConvert.DeserializeObject(responseContent);

                        if (result != null && result.data != null)
                        {
                            return new UserViewModel
                            {
                                UserId = Convert.ToInt32(result.data.userId),
                                Username = result.data.username,
                                FullName = result.data.fullName,
                                Token = result.data.token
                            };
                        }
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        throw new UnauthorizedAccessException("Invalid username or password");
                    }
                    else
                    {
                        throw new Exception($"Login failed: {response.StatusCode}");
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error during login: {ex.Message}", ex);
            }

            return null;
        }
    }
}
