using System;
using System.ComponentModel.DataAnnotations;

namespace ClaimSubmissionManagement.MVC.Models
{
    /// <summary>
    /// View Model for Claim List display
    /// </summary>
    public class ClaimListViewModel
    {
        public int ClaimId { get; set; }
        public string ClaimNumber { get; set; }
        public string PatientName { get; set; }
        public string ProviderName { get; set; }
        public DateTime DateOfService { get; set; }
        public decimal ClaimAmount { get; set; }
        public string ClaimStatus { get; set; }
    }

    /// <summary>
    /// View Model for Add Claim page
    /// </summary>
    public class AddClaimViewModel
    {
        [Required(ErrorMessage = "Claim Number is mandatory.")]
        [StringLength(50)]
        public string ClaimNumber { get; set; }

        [Required(ErrorMessage = "Patient Name is mandatory.")]
        [StringLength(100)]
        public string PatientName { get; set; }

        [Required(ErrorMessage = "Provider Name is mandatory.")]
        [StringLength(100)]
        public string ProviderName { get; set; }

        [Required(ErrorMessage = "Date of Service is mandatory.")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfService { get; set; }

        [Required(ErrorMessage = "Claim Amount is mandatory.")]
        [Range(0.01, 9999999.99)]
        public decimal ClaimAmount { get; set; }

        [Required(ErrorMessage = "Claim Status is mandatory.")]
        [StringLength(50)]
        public string ClaimStatus { get; set; }
    }

    /// <summary>
    /// View Model for Edit Claim page
    /// </summary>
    public class EditClaimViewModel
    {
        public int ClaimId { get; set; }

        [StringLength(50)]
        public string ClaimNumber { get; set; }

        [Required(ErrorMessage = "Patient Name is mandatory.")]
        [StringLength(100)]
        public string PatientName { get; set; }

        [Required(ErrorMessage = "Provider Name is mandatory.")]
        [StringLength(100)]
        public string ProviderName { get; set; }

        [Required(ErrorMessage = "Date of Service is mandatory.")]
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfService { get; set; }

        [Required(ErrorMessage = "Claim Amount is mandatory.")]
        [Range(0.01, 9999999.99)]
        public decimal ClaimAmount { get; set; }

        [Required(ErrorMessage = "Claim Status is mandatory.")]
        [StringLength(50)]
        public string ClaimStatus { get; set; }
    }

    /// <summary>
    /// View Model for Login page
    /// </summary>
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Username is mandatory.")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is mandatory.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Display(Name = "Remember Me")]
        public bool RememberMe { get; set; }
    }

    /// <summary>
    /// View Model for user session
    /// </summary>
    public class UserViewModel
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Token { get; set; }
    }
}
