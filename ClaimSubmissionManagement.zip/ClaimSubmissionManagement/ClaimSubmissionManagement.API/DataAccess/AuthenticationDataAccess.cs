using System;
using System.Data;
using System.Data.SqlClient;

namespace ClaimSubmissionManagement.API.DataAccess
{
    /// <summary>
    /// Data Access Layer for Authentication - handles user login via stored procedures
    /// </summary>
    public class AuthenticationDataAccess
    {
        private readonly string _connectionString;

        public AuthenticationDataAccess(string connectionString)
        {
            _connectionString = connectionString;
        }

        /// <summary>
        /// Validate user credentials via sp_User_ValidateCredentials
        /// </summary>
        public int ValidateUser(string username, string passwordHash)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_User_ValidateCredentials", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@PasswordHash", passwordHash);

                        SqlParameter userIdParam = new SqlParameter("@UserId", SqlDbType.Int);
                        userIdParam.Direction = ParameterDirection.Output;
                        command.Parameters.Add(userIdParam);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();

                        return (int)userIdParam.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error validating user: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Update user's last login timestamp via sp_User_UpdateLastLogin
        /// </summary>
        public void UpdateLastLogin(int userId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_User_UpdateLastLogin", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@UserId", userId);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating last login: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Create a new user via sp_User_Create
        /// </summary>
        public int CreateUser(string username, string passwordHash, string email, string fullName)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_User_Create", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@Username", username);
                        command.Parameters.AddWithValue("@PasswordHash", passwordHash);
                        command.Parameters.AddWithValue("@Email", email);
                        command.Parameters.AddWithValue("@FullName", fullName);

                        SqlParameter userIdParam = new SqlParameter("@UserId", SqlDbType.Int);
                        userIdParam.Direction = ParameterDirection.Output;
                        command.Parameters.Add(userIdParam);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();

                        return (int)userIdParam.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error creating user: {ex.Message}", ex);
            }
        }
    }
}
