using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using ClaimSubmissionManagement.API.DTOs;

namespace ClaimSubmissionManagement.API.DataAccess
{
    /// <summary>
    /// Data Access Layer for Claims - handles all database operations via stored procedures
    /// </summary>
    public class ClaimDataAccess
    {
        private readonly string _connectionString;

        public ClaimDataAccess(string connectionString)
        {
            _connectionString = connectionString;
        }

        /// <summary>
        /// Create a new claim via sp_Claim_Create stored procedure
        /// </summary>
        public int CreateClaim(CreateClaimRequest request, int userId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_Claim_Create", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@ClaimNumber", request.ClaimNumber);
                        command.Parameters.AddWithValue("@PatientName", request.PatientName);
                        command.Parameters.AddWithValue("@ProviderName", request.ProviderName);
                        command.Parameters.AddWithValue("@DateOfService", request.DateOfService);
                        command.Parameters.AddWithValue("@ClaimAmount", request.ClaimAmount);
                        command.Parameters.AddWithValue("@ClaimStatus", request.ClaimStatus);
                        command.Parameters.AddWithValue("@CreatedBy", userId);

                        SqlParameter claimIdParam = new SqlParameter("@ClaimId", SqlDbType.Int);
                        claimIdParam.Direction = ParameterDirection.Output;
                        command.Parameters.Add(claimIdParam);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();

                        return (int)claimIdParam.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error creating claim: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Get claim by ClaimId via sp_Claim_GetById stored procedure
        /// </summary>
        public ClaimDTO GetClaimById(int claimId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_Claim_GetById", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@ClaimId", claimId);

                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return MapClaimFromReader(reader);
                            }
                        }
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving claim: {ex.Message}", ex);
            }

            return null;
        }

        /// <summary>
        /// Get claim by ClaimNumber via sp_Claim_GetByClaimNumber stored procedure
        /// </summary>
        public ClaimDTO GetClaimByNumber(string claimNumber)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_Claim_GetByClaimNumber", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@ClaimNumber", claimNumber);

                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return MapClaimFromReader(reader);
                            }
                        }
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving claim by number: {ex.Message}", ex);
            }

            return null;
        }

        /// <summary>
        /// Get all claims with pagination via sp_Claim_GetAll stored procedure
        /// </summary>
        public PaginationResponse<ClaimDTO> GetAllClaims(int pageNumber = 1, int pageSize = 10)
        {
            var claims = new List<ClaimDTO>();
            int totalClaims = 0;

            try
            {
                // Get paginated claims
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_Claim_GetAll", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@PageNumber", pageNumber);
                        command.Parameters.AddWithValue("@PageSize", pageSize);

                        connection.Open();
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                claims.Add(MapClaimFromReader(reader));
                            }
                        }
                        connection.Close();
                    }
                }

                // Get total count
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_Claim_GetCount", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        connection.Open();
                        totalClaims = (int)command.ExecuteScalar();
                        connection.Close();
                    }
                }

                return new PaginationResponse<ClaimDTO>
                {
                    Items = claims,
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    TotalItems = totalClaims
                };
            }
            catch (Exception ex)
            {
                throw new Exception($"Error retrieving claims: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Update an existing claim via sp_Claim_Update stored procedure
        /// </summary>
        public void UpdateClaim(UpdateClaimRequest request, int userId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_Claim_Update", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@ClaimId", request.ClaimId);
                        command.Parameters.AddWithValue("@PatientName", request.PatientName);
                        command.Parameters.AddWithValue("@ProviderName", request.ProviderName);
                        command.Parameters.AddWithValue("@DateOfService", request.DateOfService);
                        command.Parameters.AddWithValue("@ClaimAmount", request.ClaimAmount);
                        command.Parameters.AddWithValue("@ClaimStatus", request.ClaimStatus);
                        command.Parameters.AddWithValue("@LastModifiedBy", userId);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error updating claim: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Delete a claim via sp_Claim_Delete stored procedure
        /// </summary>
        public void DeleteClaim(int claimId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(_connectionString))
                {
                    using (SqlCommand command = new SqlCommand("sp_Claim_Delete", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@ClaimId", claimId);

                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"Error deleting claim: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Helper method to map database reader to ClaimDTO
        /// </summary>
        private ClaimDTO MapClaimFromReader(SqlDataReader reader)
        {
            return new ClaimDTO
            {
                ClaimId = reader.GetInt32(reader.GetOrdinal("ClaimId")),
                ClaimNumber = reader.GetString(reader.GetOrdinal("ClaimNumber")),
                PatientName = reader.GetString(reader.GetOrdinal("PatientName")),
                ProviderName = reader.GetString(reader.GetOrdinal("ProviderName")),
                DateOfService = reader.GetDateTime(reader.GetOrdinal("DateOfService")),
                ClaimAmount = reader.GetDecimal(reader.GetOrdinal("ClaimAmount")),
                ClaimStatus = reader.GetString(reader.GetOrdinal("ClaimStatus")),
                CreatedDate = reader.GetDateTime(reader.GetOrdinal("CreatedDate")),
                LastModifiedDate = reader.IsDBNull(reader.GetOrdinal("LastModifiedDate")) ? 
                    (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("LastModifiedDate"))
            };
        }
    }
}
