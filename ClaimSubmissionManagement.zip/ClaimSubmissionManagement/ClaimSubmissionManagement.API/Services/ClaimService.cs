using System;
using System.Collections.Generic;
using ClaimSubmissionManagement.API.DTOs;
using ClaimSubmissionManagement.API.DataAccess;

namespace ClaimSubmissionManagement.API.Services
{
    /// <summary>
    /// Business logic service for Claim operations
    /// </summary>
    public interface IClaimService
    {
        ClaimDTO GetClaimById(int claimId);
        ClaimDTO GetClaimByNumber(string claimNumber);
        PaginationResponse<ClaimDTO> GetAllClaims(int pageNumber = 1, int pageSize = 10);
        int CreateClaim(CreateClaimRequest request, int userId);
        void UpdateClaim(UpdateClaimRequest request, int userId);
        void DeleteClaim(int claimId);
        List<string> ValidateClaimRequest(CreateClaimRequest request);
        List<string> ValidateUpdateClaimRequest(UpdateClaimRequest request);
    }

    public class ClaimService : IClaimService
    {
        private readonly ClaimDataAccess _dataAccess;

        public ClaimService(string connectionString)
        {
            _dataAccess = new ClaimDataAccess(connectionString);
        }

        /// <summary>
        /// Get claim by ID from database
        /// </summary>
        public ClaimDTO GetClaimById(int claimId)
        {
            if (claimId <= 0)
                throw new ArgumentException("Invalid ClaimId");

            return _dataAccess.GetClaimById(claimId);
        }

        /// <summary>
        /// Get claim by claim number from database
        /// </summary>
        public ClaimDTO GetClaimByNumber(string claimNumber)
        {
            if (string.IsNullOrWhiteSpace(claimNumber))
                throw new ArgumentException("ClaimNumber cannot be empty");

            return _dataAccess.GetClaimByNumber(claimNumber);
        }

        /// <summary>
        /// Get all claims with pagination
        /// </summary>
        public PaginationResponse<ClaimDTO> GetAllClaims(int pageNumber = 1, int pageSize = 10)
        {
            if (pageNumber < 1)
                pageNumber = 1;
            if (pageSize < 1 || pageSize > 100)
                pageSize = 10;

            return _dataAccess.GetAllClaims(pageNumber, pageSize);
        }

        /// <summary>
        /// Create a new claim with validation
        /// </summary>
        public int CreateClaim(CreateClaimRequest request, int userId)
        {
            var errors = ValidateClaimRequest(request);
            if (errors.Count > 0)
            {
                throw new ArgumentException($"Validation failed: {string.Join("; ", errors)}");
            }

            // Check if claim number already exists
            var existingClaim = _dataAccess.GetClaimByNumber(request.ClaimNumber);
            if (existingClaim != null)
            {
                throw new InvalidOperationException($"Claim with number {request.ClaimNumber} already exists");
            }

            return _dataAccess.CreateClaim(request, userId);
        }

        /// <summary>
        /// Update an existing claim with validation
        /// </summary>
        public void UpdateClaim(UpdateClaimRequest request, int userId)
        {
            var errors = ValidateUpdateClaimRequest(request);
            if (errors.Count > 0)
            {
                throw new ArgumentException($"Validation failed: {string.Join("; ", errors)}");
            }

            // Verify claim exists
            var existingClaim = _dataAccess.GetClaimById(request.ClaimId);
            if (existingClaim == null)
            {
                throw new InvalidOperationException($"Claim with ID {request.ClaimId} not found");
            }

            _dataAccess.UpdateClaim(request, userId);
        }

        /// <summary>
        /// Delete a claim
        /// </summary>
        public void DeleteClaim(int claimId)
        {
            if (claimId <= 0)
                throw new ArgumentException("Invalid ClaimId");

            _dataAccess.DeleteClaim(claimId);
        }

        /// <summary>
        /// Validate claim creation request - all fields are mandatory
        /// </summary>
        public List<string> ValidateClaimRequest(CreateClaimRequest request)
        {
            var errors = new List<string>();

            if (request == null)
            {
                errors.Add("Claim request is required");
                return errors;
            }

            if (string.IsNullOrWhiteSpace(request.ClaimNumber))
                errors.Add("Claim Number is mandatory.");

            if (string.IsNullOrWhiteSpace(request.PatientName))
                errors.Add("Patient Name is mandatory.");

            if (string.IsNullOrWhiteSpace(request.ProviderName))
                errors.Add("Provider Name is mandatory.");

            if (request.DateOfService == default(DateTime) || request.DateOfService > DateTime.Now)
                errors.Add("Date of Service is mandatory.");

            if (request.ClaimAmount <= 0)
                errors.Add("Claim Amount is mandatory.");

            if (string.IsNullOrWhiteSpace(request.ClaimStatus))
                errors.Add("Claim Status is mandatory.");

            return errors;
        }

        /// <summary>
        /// Validate claim update request - all fields are mandatory
        /// </summary>
        public List<string> ValidateUpdateClaimRequest(UpdateClaimRequest request)
        {
            var errors = new List<string>();

            if (request == null)
            {
                errors.Add("Claim request is required");
                return errors;
            }

            if (request.ClaimId <= 0)
                errors.Add("Claim ID is mandatory.");

            if (string.IsNullOrWhiteSpace(request.PatientName))
                errors.Add("Patient Name is mandatory.");

            if (string.IsNullOrWhiteSpace(request.ProviderName))
                errors.Add("Provider Name is mandatory.");

            if (request.DateOfService == default(DateTime) || request.DateOfService > DateTime.Now)
                errors.Add("Date of Service is mandatory.");

            if (request.ClaimAmount <= 0)
                errors.Add("Claim Amount is mandatory.");

            if (string.IsNullOrWhiteSpace(request.ClaimStatus))
                errors.Add("Claim Status is mandatory.");

            return errors;
        }
    }
}
