using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using ClaimSubmissionManagement.API.DTOs;
using ClaimSubmissionManagement.API.DataAccess;

namespace ClaimSubmissionManagement.API.Services
{
    /// <summary>
    /// Authentication service for user login and registration
    /// </summary>
    public interface IAuthenticationService
    {
        LoginResponse Login(LoginRequest request);
        int Register(RegisterRequest request);
        string HashPassword(string password);
        bool VerifyPassword(string password, string hash);
    }

    public class AuthenticationService : IAuthenticationService
    {
        private readonly AuthenticationDataAccess _dataAccess;

        public AuthenticationService(string connectionString)
        {
            _dataAccess = new AuthenticationDataAccess(connectionString);
        }

        /// <summary>
        /// Login user with username and password
        /// </summary>
        public LoginResponse Login(LoginRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Password))
            {
                throw new ArgumentException("Username and password are required");
            }

            // Hash the password
            string passwordHash = HashPassword(request.Password);

            // Validate credentials via stored procedure
            int userId = _dataAccess.ValidateUser(request.Username, passwordHash);

            if (userId == -1)
            {
                throw new UnauthorizedAccessException("Invalid username or password");
            }

            // Update last login
            _dataAccess.UpdateLastLogin(userId);

            // Generate a simple token (in production, use JWT or similar)
            string token = GenerateToken(userId, request.Username);

            return new LoginResponse
            {
                UserId = userId,
                Username = request.Username,
                FullName = request.Username, // In production, fetch this from database
                Token = token
            };
        }

        /// <summary>
        /// Register a new user
        /// </summary>
        public int Register(RegisterRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.Username) || string.IsNullOrWhiteSpace(request.Password))
            {
                throw new ArgumentException("Username and password are required");
            }

            // Validate password strength (minimum 8 characters, must contain uppercase, lowercase, and digit)
            if (!ValidatePasswordStrength(request.Password))
            {
                throw new ArgumentException("Password must be at least 8 characters and contain uppercase, lowercase, and digits");
            }

            // Hash the password
            string passwordHash = HashPassword(request.Password);

            // Create user via stored procedure
            int userId = _dataAccess.CreateUser(request.Username, passwordHash, request.Email, request.FullName);

            if (userId == -1)
            {
                throw new InvalidOperationException("Failed to create user account");
            }

            return userId;
        }

        /// <summary>
        /// Hash password using SHA256
        /// </summary>
        public string HashPassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
                throw new ArgumentException("Password cannot be empty");

            using (var sha256 = SHA256.Create())
            {
                var hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }

        /// <summary>
        /// Verify password against hash
        /// </summary>
        public bool VerifyPassword(string password, string hash)
        {
            if (string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(hash))
                return false;

            var hashOfInput = HashPassword(password);
            return hashOfInput.Equals(hash, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// Validate password strength
        /// </summary>
        private bool ValidatePasswordStrength(string password)
        {
            if (string.IsNullOrWhiteSpace(password) || password.Length < 8)
                return false;

            bool hasUpper = false, hasLower = false, hasDigit = false;

            foreach (char c in password)
            {
                if (char.IsUpper(c)) hasUpper = true;
                if (char.IsLower(c)) hasLower = true;
                if (char.IsDigit(c)) hasDigit = true;
            }

            return hasUpper && hasLower && hasDigit;
        }

        /// <summary>
        /// Generate authentication token (simplified - in production use JWT)
        /// </summary>
        private string GenerateToken(int userId, string username)
        {
            // Simple token generation - in production use JWT
            return Convert.ToBase64String(Encoding.UTF8.GetBytes($"{userId}:{username}:{DateTime.UtcNow.Ticks}"));
        }
    }
}
