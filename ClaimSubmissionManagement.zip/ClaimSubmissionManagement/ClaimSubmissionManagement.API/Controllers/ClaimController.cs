using System;
using System.Collections.Generic;
using System.Web.Http;
using ClaimSubmissionManagement.API.DTOs;
using ClaimSubmissionManagement.API.Services;

namespace ClaimSubmissionManagement.API.Controllers
{
    /// <summary>
    /// RESTful Web API Controller for Claim Management
    /// All operations are performed through the service layer which communicates via stored procedures
    /// </summary>
    [RoutePrefix("api/claims")]
    public class ClaimController : ApiController
    {
        private readonly IClaimService _claimService;

        public ClaimController(string connectionString)
        {
            _claimService = new ClaimService(connectionString);
        }

        /// <summary>
        /// GET: api/claims
        /// Retrieve all claims with pagination
        /// </summary>
        [HttpGet]
        [Route("")]
        public IHttpActionResult GetAllClaims(int pageNumber = 1, int pageSize = 10)
        {
            try
            {
                var result = _claimService.GetAllClaims(pageNumber, pageSize);
                var response = new ApiResponse<PaginationResponse<ClaimDTO>>
                {
                    Success = true,
                    Message = "Claims retrieved successfully",
                    Data = result
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                var response = new ApiResponse<object>
                {
                    Success = false,
                    Message = "Error retrieving claims",
                    Errors = new List<string> { ex.Message }
                };
                return InternalServerError(new Exception(ex.Message));
            }
        }

        /// <summary>
        /// GET: api/claims/{id}
        /// Retrieve a specific claim by ID
        /// </summary>
        [HttpGet]
        [Route("{id}")]
        public IHttpActionResult GetClaimById(int id)
        {
            try
            {
                var claim = _claimService.GetClaimById(id);
                if (claim == null)
                {
                    return NotFound();
                }

                var response = new ApiResponse<ClaimDTO>
                {
                    Success = true,
                    Message = "Claim retrieved successfully",
                    Data = claim
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }

        /// <summary>
        /// GET: api/claims/number/{claimNumber}
        /// Retrieve a claim by claim number
        /// </summary>
        [HttpGet]
        [Route("number/{claimNumber}")]
        public IHttpActionResult GetClaimByNumber(string claimNumber)
        {
            try
            {
                var claim = _claimService.GetClaimByNumber(claimNumber);
                if (claim == null)
                {
                    return NotFound();
                }

                var response = new ApiResponse<ClaimDTO>
                {
                    Success = true,
                    Message = "Claim retrieved successfully",
                    Data = claim
                };
                return Ok(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }

        /// <summary>
        /// POST: api/claims
        /// Create a new claim
        /// Required fields: ClaimNumber, PatientName, ProviderName, DateOfService, ClaimAmount, ClaimStatus
        /// </summary>
        [HttpPost]
        [Route("")]
        public IHttpActionResult CreateClaim([FromBody] CreateClaimRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request body cannot be empty");
            }

            try
            {
                // Validate request
                var validationErrors = _claimService.ValidateClaimRequest(request);
                if (validationErrors.Count > 0)
                {
                    var errorResponse = new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Validation failed",
                        Errors = validationErrors
                    };
                    return BadRequest(errorResponse.Message);
                }

                // Create claim (assuming userId = 1 for now, in real app this comes from authentication)
                int userId = 1;
                int claimId = _claimService.CreateClaim(request, userId);

                var response = new ApiResponse<object>
                {
                    Success = true,
                    Message = $"Claim created successfully with ID: {claimId}",
                    Data = new { ClaimId = claimId }
                };
                return Created($"api/claims/{claimId}", response);
            }
            catch (InvalidOperationException ex)
            {
                var response = new ApiResponse<object>
                {
                    Success = false,
                    Message = ex.Message
                };
                return BadRequest(response.Message);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }

        /// <summary>
        /// PUT: api/claims/{id}
        /// Update an existing claim
        /// Editable fields: PatientName, ProviderName, DateOfService, ClaimAmount, ClaimStatus
        /// </summary>
        [HttpPut]
        [Route("{id}")]
        public IHttpActionResult UpdateClaim(int id, [FromBody] UpdateClaimRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request body cannot be empty");
            }

            try
            {
                request.ClaimId = id;

                // Validate request
                var validationErrors = _claimService.ValidateUpdateClaimRequest(request);
                if (validationErrors.Count > 0)
                {
                    var errorResponse = new ApiResponse<object>
                    {
                        Success = false,
                        Message = "Validation failed",
                        Errors = validationErrors
                    };
                    return BadRequest(errorResponse.Message);
                }

                // Update claim (assuming userId = 1 for now, in real app this comes from authentication)
                int userId = 1;
                _claimService.UpdateClaim(request, userId);

                var response = new ApiResponse<object>
                {
                    Success = true,
                    Message = "Claim updated successfully"
                };
                return Ok(response);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }

        /// <summary>
        /// DELETE: api/claims/{id}
        /// Delete a claim
        /// </summary>
        [HttpDelete]
        [Route("{id}")]
        public IHttpActionResult DeleteClaim(int id)
        {
            try
            {
                _claimService.DeleteClaim(id);

                var response = new ApiResponse<object>
                {
                    Success = true,
                    Message = "Claim deleted successfully"
                };
                return Ok(response);
            }
            catch (InvalidOperationException ex)
            {
                return NotFound();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }
    }
}
