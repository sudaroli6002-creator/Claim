using System;
using System.Web.Http;
using ClaimSubmissionManagement.API.DTOs;
using ClaimSubmissionManagement.API.Services;

namespace ClaimSubmissionManagement.API.Controllers
{
    /// <summary>
    /// Web API Controller for Authentication
    /// Handles user login and registration
    /// </summary>
    [RoutePrefix("api/auth")]
    public class AuthenticationController : ApiController
    {
        private readonly IAuthenticationService _authService;

        public AuthenticationController(string connectionString)
        {
            _authService = new AuthenticationService(connectionString);
        }

        /// <summary>
        /// POST: api/auth/login
        /// Authenticate user with username and password
        /// </summary>
        [HttpPost]
        [Route("login")]
        [AllowAnonymous]
        public IHttpActionResult Login([FromBody] LoginRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request body cannot be empty");
            }

            try
            {
                var loginResponse = _authService.Login(request);

                var response = new ApiResponse<LoginResponse>
                {
                    Success = true,
                    Message = "Login successful",
                    Data = loginResponse
                };

                return Ok(response);
            }
            catch (UnauthorizedAccessException ex)
            {
                var response = new ApiResponse<object>
                {
                    Success = false,
                    Message = ex.Message
                };
                return Unauthorized();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }

        /// <summary>
        /// POST: api/auth/register
        /// Register a new user account
        /// </summary>
        [HttpPost]
        [Route("register")]
        [AllowAnonymous]
        public IHttpActionResult Register([FromBody] RegisterRequest request)
        {
            if (request == null)
            {
                return BadRequest("Request body cannot be empty");
            }

            try
            {
                int userId = _authService.Register(request);

                var response = new ApiResponse<object>
                {
                    Success = true,
                    Message = "User registered successfully",
                    Data = new { UserId = userId }
                };

                return Created($"api/auth/{userId}", response);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                var response = new ApiResponse<object>
                {
                    Success = false,
                    Message = ex.Message
                };
                return BadRequest(response.Message);
            }
            catch (Exception ex)
            {
                return InternalServerError(new Exception(ex.Message));
            }
        }
    }

    /// <summary>
    /// Custom attribute for allowing anonymous access to API endpoints
    /// </summary>
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class)]
    public class AllowAnonymousAttribute : Attribute
    {
    }
}
