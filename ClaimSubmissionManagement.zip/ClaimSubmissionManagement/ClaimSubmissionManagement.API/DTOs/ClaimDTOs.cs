namespace ClaimSubmissionManagement.API.DTOs
{
    /// <summary>
    /// Data Transfer Object for Claim creation and updates
    /// </summary>
    public class ClaimDTO
    {
        public int ClaimId { get; set; }
        public string ClaimNumber { get; set; }
        public string PatientName { get; set; }
        public string ProviderName { get; set; }
        public DateTime DateOfService { get; set; }
        public decimal ClaimAmount { get; set; }
        public string ClaimStatus { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? LastModifiedDate { get; set; }
    }

    /// <summary>
    /// DTO for creating a new claim
    /// </summary>
    public class CreateClaimRequest
    {
        public string ClaimNumber { get; set; }
        public string PatientName { get; set; }
        public string ProviderName { get; set; }
        public DateTime DateOfService { get; set; }
        public decimal ClaimAmount { get; set; }
        public string ClaimStatus { get; set; }
    }

    /// <summary>
    /// DTO for updating an existing claim
    /// </summary>
    public class UpdateClaimRequest
    {
        public int ClaimId { get; set; }
        public string PatientName { get; set; }
        public string ProviderName { get; set; }
        public DateTime DateOfService { get; set; }
        public decimal ClaimAmount { get; set; }
        public string ClaimStatus { get; set; }
    }

    /// <summary>
    /// DTO for API response
    /// </summary>
    public class ApiResponse<T>
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public T Data { get; set; }
        public List<string> Errors { get; set; } = new List<string>();
    }

    /// <summary>
    /// DTO for pagination
    /// </summary>
    public class PaginationResponse<T>
    {
        public List<T> Items { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int TotalItems { get; set; }
    }
}
