namespace ClaimSubmissionManagement.API.DTOs
{
    /// <summary>
    /// DTO for user login request
    /// </summary>
    public class LoginRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    /// <summary>
    /// DTO for login response containing user information and token
    /// </summary>
    public class LoginResponse
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string FullName { get; set; }
        public string Token { get; set; }
    }

    /// <summary>
    /// DTO for user registration request
    /// </summary>
    public class RegisterRequest
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string FullName { get; set; }
    }
}
